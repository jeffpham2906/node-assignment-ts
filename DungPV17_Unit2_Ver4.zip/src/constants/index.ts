const NOT_FOUND = "NOT_FOUND";
const UNAUTHORIZED = "UNAUTHORIZED";
const ACCESS_DENIED = "ACCESS_DENIED";
const SUCCESS = "SUCCESS";
const FAILED = "FAILED";
export const STATUS_MESSAGES = {
    NOT_FOUND,
    UNAUTHORIZED,
    ACCESS_DENIED,
    SUCCESS,
    FAILED,
};

export enum Method {
    CREATE = "create",
    READ = "read",
    UPDATE = "update",
    DELETE = "delete",
    FULL = "full",
}
