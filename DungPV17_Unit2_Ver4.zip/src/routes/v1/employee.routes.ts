import { Router } from "express";
import { EmployeeService } from "../../services/employee.service";
import { EmployeeController } from "../../controllers/employee.controller";
import { employeeSchema, employeeSchemaUpdate } from "../../validations/employee.validations";
import authenticate from "../../middlewares/authenticate";
import { Method } from "../../constants";

// api/v1/employees
const employeeRoutes = Router();
const employeeService = new EmployeeService();
const employeeController = new EmployeeController(employeeService);

employeeRoutes.get("/", authenticate({ key: "employees", method: Method.READ }), employeeController.getEmployees);
employeeRoutes.post(
    "/",
    authenticate({ key: "employees", method: Method.CREATE }),
    employeeSchema,
    employeeController.createEmployee
);
employeeRoutes.put(
    "/:id",
    authenticate({ key: "employees", method: Method.UPDATE }),
    employeeSchemaUpdate,
    employeeController.updateEmployee
);
employeeRoutes.delete(
    "/:id",
    authenticate({ key: "employees", method: Method.DELETE }),
    employeeController.deleteEmployee
);

export default employeeRoutes;
