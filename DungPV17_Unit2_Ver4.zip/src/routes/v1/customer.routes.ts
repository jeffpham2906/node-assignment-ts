import { Router } from "express";
import { CustomerService } from "../../services/customer.service";
import { CustomerController } from "../../controllers/customer.controller";
import { customerSchema, customerSchemaUpdate } from "../../validations/customer.validations";
import authenticate from "../../middlewares/authenticate";
import { Method } from "../../constants";

// api/v1/customers
const customerRoutes = Router();
const customerService = new CustomerService();
const customerController = new CustomerController(customerService);

customerRoutes.get("/", authenticate({ key: "customers", method: Method.READ }), customerController.getCustomers);

customerRoutes.post(
    "/",
    authenticate({ key: "customers", method: Method.CREATE }),
    customerSchema,
    customerController.createCustomer
);

customerRoutes.put(
    "/:id",
    authenticate({ key: "customers", method: Method.UPDATE }),
    customerSchemaUpdate,
    customerController.updateCustomer
);
customerRoutes.delete(
    "/:id",
    authenticate({ key: "customers", method: Method.DELETE }),
    customerController.deleteCustomer
);

export default customerRoutes;
