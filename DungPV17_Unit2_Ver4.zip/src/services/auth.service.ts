import { User } from "@prisma/client";
import { IAuthService } from "../interfaces/IAuthService";
import { prisma } from "../lib/prisma";
import bcrypt from "bcrypt";
import { APIError } from "../utils/error";
import { StatusCodes } from "http-status-codes";
import { STATUS_MESSAGES } from "../constants";

export class AuthService implements IAuthService {
    onLogin = async (user: Omit<User, "employeeNumber">): Promise<User> => {
        const loggedInUser = await prisma.user.findFirst({
            where: {
                username: user.username,
            },
            select: {
                username: true,
                password: true,
                employee: {
                    include: {
                        employeeRole: true,
                    },
                },
            },
        });
        if (!loggedInUser) {
            throw new APIError(
                StatusCodes.NOT_FOUND,
                STATUS_MESSAGES.NOT_FOUND,
                `Cannot find user with username ${user.username}`
            );
        }
        const isCorrectPassword = await bcrypt.compare(user.password, loggedInUser.password);
        if (!isCorrectPassword) {
            throw new APIError(
                StatusCodes.UNAUTHORIZED,
                STATUS_MESSAGES.UNAUTHORIZED,
                `Password not correct with username ${user.username}`
            );
        }
        let format = {} as any;
        const { employee, ..._user } = loggedInUser;
        if (employee) {
            const { employeeRole, ..._employee } = employee;
            format = { ...format, ..._employee };
            if (employeeRole) {
                format["permissions"] = [...Array.from(employeeRole.permissions as any)];
            }
        }

        return {
            ..._user,
            ...format,
        };
    };
    onRegister = async (user: User): Promise<User> => {
        const salt = await bcrypt.genSalt(10);
        user.password = await bcrypt.hash(user.password, salt);
        const createdUser = await prisma.user.create({
            data: user,
        });
        return createdUser;
    };

    onRefreshToken = async (refreshToken: string): Promise<any> => {
        throw new Error("Method not implemented.");
    };
}
